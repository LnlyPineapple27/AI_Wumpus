# AI_Wumpus
AI project 2

Members:
+ Phan Tan Dat - 18127078
+ Tran Phuoc Loc - 18127130
